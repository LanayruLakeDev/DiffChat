export default function Loading() {
  return <div aria-label=""></div>;
}
