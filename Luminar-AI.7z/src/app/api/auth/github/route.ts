import { NextRequest } from "next/server";

/**
 * Custom GitHub OAuth initiation route
 * This bypasses Better Auth to ensure proper repo scope is requested
 */
export async function GET(request: NextRequest) {
  const clientId = process.env.GITHUB_CLIENT_ID;
  
  if (!clientId) {
    console.error("❌ GITHUB_CLIENT_ID not configured");
    return new Response("GitHub OAuth not configured", { status: 500 });
  }

  // Generate a random state for security
  const state = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  
  const redirectUri = `${request.nextUrl.origin}/api/auth/callback/github`;
  
  // Properly formatted GitHub OAuth URL with repo scope
  const githubAuthUrl = new URL('https://github.com/login/oauth/authorize');
  githubAuthUrl.searchParams.set('client_id', clientId);
  githubAuthUrl.searchParams.set('redirect_uri', redirectUri);
  githubAuthUrl.searchParams.set('scope', 'repo user:email read:user'); // Repository permissions!
  githubAuthUrl.searchParams.set('state', state);
  githubAuthUrl.searchParams.set('allow_signup', 'true');

  console.log('🚀 CUSTOM GITHUB OAUTH: Redirecting to GitHub with repo scope');
  console.log('  🔗 URL:', githubAuthUrl.toString());
  console.log('  🎯 Scopes requested: repo user:email read:user');
  console.log('  📍 Redirect URI:', redirectUri);
  console.log('  🔐 State:', state);

  // Create redirect response with state cookie using NextResponse
  const response = new Response(null, {
    status: 302,
    headers: {
      'Location': githubAuthUrl.toString(),
      'Set-Cookie': `github_oauth_state=${state}; HttpOnly; Secure=${process.env.NODE_ENV === 'production'}; SameSite=Lax; Max-Age=600; Path=/`
    }
  });

  return response;
}
