import { NextRequest } from "next/server";
import { pgDb } from "lib/db/pg/db.pg";
import { UserSchema, AccountSchema, SessionSchema } from "lib/db/pg/schema.pg";
import { eq } from "drizzle-orm";

/**
 * GitHub OAuth callback handler
 * Handles the GitHub OAuth response and creates/updates user accounts
 * This matches the GitHub OAuth app callback URL: /api/auth/callback/github
 */
export async function GET(request: NextRequest) {
  const url = new URL(request.url);
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const error = url.searchParams.get('error');

  console.log('🔄 GITHUB OAUTH CALLBACK: Processing GitHub response');
  console.log('  📨 Code received:', !!code);
  console.log('  🔐 State:', state);
  console.log('  ❌ Error:', error);

  if (error) {
    console.error('❌ GitHub OAuth error:', error);
    return Response.redirect(`${url.origin}/sign-in?error=github_oauth_failed`);
  }

  if (!code) {
    console.error('❌ No authorization code received');
    return Response.redirect(`${url.origin}/sign-in?error=no_code`);
  }

  try {
    // Exchange code for access token
    console.log('🔄 Exchanging code for access token...');
    const tokenResponse = await fetch('https://github.com/login/oauth/access_token', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        client_id: process.env.GITHUB_CLIENT_ID,
        client_secret: process.env.GITHUB_CLIENT_SECRET,
        code,
      }),
    });

    if (!tokenResponse.ok) {
      console.error('❌ Failed to exchange code for token:', tokenResponse.status);
      return Response.redirect(`${url.origin}/sign-in?error=token_exchange_failed`);
    }

    const tokenData = await tokenResponse.json();
    const accessToken = tokenData.access_token;
    const scope = tokenData.scope;

    console.log('✅ GITHUB TOKEN RECEIVED:');
    console.log('  🔑 Token received:', !!accessToken);
    console.log('  🎯 Scopes granted:', scope);
    console.log('  ✅ Has repo scope:', scope?.includes('repo') || false);

    if (!accessToken) {
      console.error('❌ No access token in response');
      return Response.redirect(`${url.origin}/sign-in?error=no_token`);
    }

    // Get user info from GitHub
    console.log('👤 Fetching user information from GitHub...');
    const userResponse = await fetch('https://api.github.com/user', {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Accept': 'application/vnd.github.v3+json',
      },
    });

    if (!userResponse.ok) {
      console.error('❌ Failed to fetch user info:', userResponse.status);
      return Response.redirect(`${url.origin}/sign-in?error=user_fetch_failed`);
    }

    const githubUser = await userResponse.json();
    console.log('👤 GitHub user info:');
    console.log('  🆔 ID:', githubUser.id);
    console.log('  👤 Login:', githubUser.login);
    console.log('  📧 Email:', githubUser.email);
    console.log('  🖼️ Avatar:', githubUser.avatar_url);

    // Get user's email if not public
    let email = githubUser.email;
    if (!email) {
      console.log('📧 Fetching user emails...');
      const emailResponse = await fetch('https://api.github.com/user/emails', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Accept': 'application/vnd.github.v3+json',
        },
      });

      if (emailResponse.ok) {
        const emails = await emailResponse.json();
        const primaryEmail = emails.find((e: any) => e.primary);
        email = primaryEmail?.email || emails[0]?.email;
        console.log('📧 Primary email found:', email);
      }
    }

    // Create or update user in database
    console.log('💾 Creating/updating user in database...');
    
    // Check if user exists by GitHub ID
    const existingAccounts = await pgDb
      .select()
      .from(AccountSchema)
      .where(eq(AccountSchema.accountId, githubUser.id.toString()));

    let userId: string;
    
    if (existingAccounts.length > 0) {
      // Update existing account
      userId = existingAccounts[0].userId;
      console.log('🔄 Updating existing account for user:', userId);
      
      await pgDb
        .update(AccountSchema)
        .set({
          accessToken,
          scope,
          updatedAt: new Date(),
        })
        .where(eq(AccountSchema.accountId, githubUser.id.toString()));
        
    } else {
      // Create new user and account
      console.log('🆕 Creating new user and account...');
      
      const [newUser] = await pgDb
        .insert(UserSchema)
        .values({
          name: githubUser.name || githubUser.login,
          email,
          emailVerified: true,
          image: githubUser.avatar_url,
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        .returning();

      userId = newUser.id;
      
      await pgDb
        .insert(AccountSchema)
        .values({
          userId,
          accountId: githubUser.id.toString(),
          providerId: 'github',
          accessToken,
          scope,
          createdAt: new Date(),
          updatedAt: new Date(),
        });
    }

    console.log('✅ GITHUB OAUTH SUCCESS:');
    console.log('  👤 User ID:', userId);
    console.log('  🔑 Token saved with scopes:', scope);
    console.log('  ✅ Repository access:', scope?.includes('repo') ? 'GRANTED' : 'DENIED');

    // Create session using Better Auth schema
    console.log('🔐 Creating user session...');
    
    const sessionToken = Math.random().toString(36).substring(2) + Math.random().toString(36).substring(2);
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

    await pgDb
      .insert(SessionSchema)
      .values({
        userId,
        token: sessionToken,
        expiresAt,
        createdAt: new Date(),
        updatedAt: new Date(),
        ipAddress: request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown',
        userAgent: request.headers.get('user-agent') || 'unknown',
      });

    console.log('✅ SESSION CREATED:');
    console.log('  🔐 Session token:', sessionToken.substring(0, 10) + '...');
    console.log('  ⏰ Expires at:', expiresAt);

    // Create response with session cookie
    const response = new Response(null, {
      status: 302,
      headers: {
        'Location': `${url.origin}/?github_login=success`,
        'Set-Cookie': `better-auth.session_token=${sessionToken}; HttpOnly; Secure=${process.env.NODE_ENV === 'production'}; SameSite=Lax; Max-Age=${7 * 24 * 60 * 60}; Path=/`
      }
    });

    console.log('🏠 Redirecting to home page with session cookie');
    return response;

  } catch (error: any) {
    console.error('❌ GitHub OAuth callback error:', error);
    return Response.redirect(`${url.origin}/sign-in?error=callback_failed`);
  }
}
