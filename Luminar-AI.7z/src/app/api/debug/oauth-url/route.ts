import { NextRequest } from "next/server";

export async function GET(request: NextRequest) {
  try {
    const clientId = process.env.GITHUB_CLIENT_ID;
    const redirectUri = `${request.nextUrl.origin}/api/auth/callback/github`;
    
    // Manual OAuth URLs with different scope configurations
    const testUrls = {
      basicScopes: `https://github.com/login/oauth/authorize?client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${encodeURIComponent("user:email read:user")}&state=test-basic`,
      withRepo: `https://github.com/login/oauth/authorize?client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${encodeURIComponent("repo user:email read:user")}&state=test-repo`,
      repoOnly: `https://github.com/login/oauth/authorize?client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${encodeURIComponent("repo")}&state=test-repo-only`
    };
    
    console.log('🔍 OAUTH URL DEBUG:');
    console.log('  CLIENT_ID:', clientId);
    console.log('  REDIRECT_URI:', redirectUri);
    console.log('  BASIC_SCOPES_URL:', testUrls.basicScopes);
    console.log('  WITH_REPO_URL:', testUrls.withRepo);
    console.log('  REPO_ONLY_URL:', testUrls.repoOnly);
    
    return Response.json({
      currentBetterAuthConfig: {
        clientId,
        redirectUri,
        scopeConfigured: "repo user:email read:user"
      },
      manualTestUrls: testUrls,
      instructions: [
        "1. Try 'withRepo' URL first - should ask for repository permissions",
        "2. If that works, the issue is with Better Auth configuration",
        "3. If it doesn't work, there might be a GitHub OAuth app configuration issue"
      ]
    });
    
  } catch (error: any) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
