// TODO: Implement Redis Cache
