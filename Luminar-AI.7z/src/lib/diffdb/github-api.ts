import { Octokit } from "@octokit/rest";
import { Base64 } from "js-base64";
import logger from "logger";

export interface GitHubFile {
  path: string;
  content: string;
  sha?: string;
}

export interface GitHubRepo {
  name: string;
  owner: string;
  private: boolean;
}

export class GitHubApiClient {
  private octokit: Octokit;
  private username: string;

  constructor(accessToken: string, username: string) {
    this.octokit = new Octokit({
      auth: accessToken,
    });
    this.username = username;
  }

  /**
   * Create a new private repository for DiffDB
   */
  async createDiffDBRepo(repoName: string = "luminar-ai-data"): Promise<GitHubRepo> {
    try {
      const { data } = await this.octokit.repos.createForAuthenticatedUser({
        name: repoName,
        private: true,
        description: "Personal AI memory and chat history powered by Luminar-AI",
        auto_init: true,
      });

      logger.info(`Created DiffDB repo: ${data.full_name}`);
      
      return {
        name: data.name,
        owner: data.owner.login,
        private: data.private,
      };
    } catch (error: any) {
      if (error.status === 422) {
        // Repository already exists
        logger.info(`DiffDB repo already exists: ${this.username}/${repoName}`);
        return {
          name: repoName,
          owner: this.username,
          private: true,
        };
      }
      throw error;
    }
  }

  /**
   * Check if DiffDB repository exists
   */
  async diffDBRepoExists(repoName: string = "luminar-ai-data"): Promise<boolean> {
    try {
      await this.octokit.repos.get({
        owner: this.username,
        repo: repoName,
      });
      return true;
    } catch (error: any) {
      if (error.status === 404) {
        return false;
      }
      throw error;
    }
  }

  /**
   * Get file content from repository
   */
  async getFile(repoName: string, filePath: string): Promise<GitHubFile | null> {
    try {
      const { data } = await this.octokit.repos.getContent({
        owner: this.username,
        repo: repoName,
        path: filePath,
      });

      if (Array.isArray(data) || data.type !== "file") {
        return null;
      }

      return {
        path: filePath,
        content: Base64.decode(data.content),
        sha: data.sha,
      };
    } catch (error: any) {
      if (error.status === 404) {
        return null;
      }
      throw error;
    }
  }

  /**
   * Create or update a file in repository
   */
  async createOrUpdateFile(
    repoName: string,
    filePath: string,
    content: string,
    message: string,
    sha?: string
  ): Promise<void> {
    try {
      await this.octokit.repos.createOrUpdateFileContents({
        owner: this.username,
        repo: repoName,
        path: filePath,
        message,
        content: Base64.encode(content),
        sha,
      });

      logger.info(`Updated file: ${filePath} in ${this.username}/${repoName}`);
    } catch (error) {
      logger.error(`Failed to update file ${filePath}:`, error);
      throw error;
    }
  }

  /**
   * List files in a directory
   */
  async listFiles(repoName: string, dirPath: string = ""): Promise<string[]> {
    try {
      const { data } = await this.octokit.repos.getContent({
        owner: this.username,
        repo: repoName,
        path: dirPath,
      });

      if (!Array.isArray(data)) {
        return [];
      }

      return data
        .filter((item) => item.type === "file")
        .map((item) => item.path);
    } catch (error: any) {
      if (error.status === 404) {
        return [];
      }
      throw error;
    }
  }

  /**
   * Delete a file from repository
   */
  async deleteFile(
    repoName: string,
    filePath: string,
    message: string,
    sha: string
  ): Promise<void> {
    try {
      await this.octokit.repos.deleteFile({
        owner: this.username,
        repo: repoName,
        path: filePath,
        message,
        sha,
      });

      logger.info(`Deleted file: ${filePath} from ${this.username}/${repoName}`);
    } catch (error) {
      logger.error(`Failed to delete file ${filePath}:`, error);
      throw error;
    }
  }

  /**
   * Initialize DiffDB repository structure
   */
  async initializeDiffDBStructure(repoName: string = "luminar-ai-data"): Promise<void> {
    const userId = this.username;
    
    // Create initial structure files
    const files = [
      {
        path: "README.md",
        content: `# ${userId}'s Luminar-AI Memory Repository

This repository contains your personal AI memory and chat history, managed by Luminar-AI using the DiffDB system.

## Structure

- \`users/${userId}/\` - Your personal memory space
  - \`memories/people/\` - Profiles and relationships
  - \`memories/contexts/\` - Thematic knowledge
  - \`memories/timeline/\` - Chronological events and chats
  - \`index.md\` - Memory index and quick lookup

## Privacy

This is your private repository. Your data belongs to you and stays under your control.
`,
      },
      {
        path: `users/${userId}/index.md`,
        content: `# ${userId} - Memory Index

## Quick Access

### Recent Conversations
[Links will be auto-generated]

### Key People
[Auto-populated as relationships develop]

### Important Topics  
[Auto-populated based on conversation themes]

---
*This index is automatically maintained by Luminar-AI*
`,
      },
      {
        path: `users/${userId}/memories/people/.gitkeep`,
        content: "# People profiles will be stored here",
      },
      {
        path: `users/${userId}/memories/contexts/.gitkeep`,
        content: "# Thematic contexts will be stored here", 
      },
      {
        path: `users/${userId}/memories/timeline/.gitkeep`,
        content: "# Timeline and chat history will be stored here",
      },
      {
        path: ".gitignore",
        content: `# Luminar-AI DiffDB
.DS_Store
*.log
temp/
`,
      },
    ];

    for (const file of files) {
      await this.createOrUpdateFile(
        repoName,
        file.path,
        file.content,
        `Initialize DiffDB structure: ${file.path}`
      );
    }

    logger.info(`Initialized DiffDB structure for user: ${userId}`);
  }
}
