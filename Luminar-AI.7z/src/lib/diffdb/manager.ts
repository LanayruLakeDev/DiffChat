import { GitHubApiClient } from "./github-api";
import { ChatThread, ChatMessage } from "app-types/chat";
import logger from "logger";
import { nanoid } from "nanoid";

export interface DiffDBUser {
  id: string;
  githubUsername: string;
  githubToken: string;
}

export class DiffDBManager {
  private githubClient: GitHubApiClient;
  private repoName: string;
  private userId: string;

  constructor(user: DiffDBUser, repoName: string = "luminar-ai-data") {
    this.githubClient = new GitHubApiClient(user.githubToken, user.githubUsername);
    this.repoName = repoName;
    this.userId = user.id;
  }

  /**
   * Initialize user's DiffDB repository
   */
  async initializeUserRepo(): Promise<void> {
    console.log('🏗️ DIFFDB MANAGER: Initializing repository for user:', this.userId);
    console.log('🏗️ DIFFDB MANAGER: Repository name:', this.repoName);
    
    try {
      const exists = await this.githubClient.diffDBRepoExists(this.repoName);
      console.log('🏗️ DIFFDB MANAGER: Repository exists:', exists);
      
      if (!exists) {
        console.log('🏗️ DIFFDB MANAGER: Creating new repository...');
        await this.githubClient.createDiffDBRepo(this.repoName);
        console.log('✅ DIFFDB MANAGER: Repository created successfully');
      }
      
      console.log('🏗️ DIFFDB MANAGER: Initializing repository structure...');
      await this.githubClient.initializeDiffDBStructure(this.repoName);
      console.log('✅ DIFFDB MANAGER: Repository structure initialized');
      
      logger.info(`DiffDB initialized for user: ${this.userId}`);
    } catch (error) {
      console.error('❌ DIFFDB MANAGER INIT ERROR:', error);
      throw error;
    }
  }

  /**
   * Save a chat thread to the timeline
   */
  async saveThread(thread: ChatThread): Promise<void> {
    console.log('💾 DIFFDB MANAGER: Saving thread to timeline');
    console.log('  📄 Thread ID:', thread.id);
    console.log('  📄 Thread Title:', thread.title);
    console.log('  📅 Created At:', thread.createdAt);

    try {
      const date = new Date(thread.createdAt);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      const filePath = `users/${this.userId}/memories/timeline/${monthKey}.md`;
      
      console.log('  📁 Timeline file path:', filePath);
      
      // Get existing timeline file or create new
      let existingFile = await this.githubClient.getFile(this.repoName, filePath);
      let content = "";
      
      if (existingFile) {
        console.log('  📄 Existing timeline file found, appending...');
        content = existingFile.content;
      } else {
        console.log('  📄 Creating new timeline file...');
        content = `# Timeline: ${monthKey} (Chat History)\n\n## Monthly Summary [MERGE_LOAD]\n- Overview: [Auto-generated summary of conversations]\n\n### Chat Threads\n\n`;
      }

      // Add thread entry
      const threadEntry = `#### Thread: ${thread.title} (${thread.id})\n- Created: ${thread.createdAt.toISOString()}\n- Status: Active\n- Messages: [Count will be updated as messages are added]\n\n`;
      
      content += threadEntry;

      console.log('  💾 Saving thread to GitHub...');
      await this.githubClient.createOrUpdateFile(
        this.repoName,
        filePath,
        content,
        `Add chat thread: ${thread.title}`,
        existingFile?.sha
      );
      console.log('✅ DIFFDB MANAGER: Thread saved successfully to GitHub');
    } catch (error) {
      console.error('❌ DIFFDB MANAGER SAVE THREAD ERROR:', error);
      throw error;
    }
  }

  /**
   * Save a chat message to the appropriate timeline
   */
  async saveMessage(message: ChatMessage, threadTitle: string): Promise<void> {
    console.log('💬 DIFFDB MANAGER: Saving message to timeline');
    console.log('  💬 Message ID:', message.id);
    console.log('  📄 Thread ID:', message.threadId);
    console.log('  👤 Role:', message.role);
    
    try {
      const date = new Date(message.createdAt);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      const filePath = `users/${this.userId}/memories/timeline/${monthKey}.md`;
      
      console.log('  📁 Message timeline file path:', filePath);
      
      let existingFile = await this.githubClient.getFile(this.repoName, filePath);
    if (!existingFile) {
      // Create monthly file if it doesn't exist
      existingFile = {
        path: filePath,
        content: `# Timeline: ${monthKey} (Chat History)\n\n## Monthly Summary [MERGE_LOAD]\n- Overview: [Auto-generated summary of conversations]\n\n### Chat Threads\n\n`,
      };
    }

    let content = existingFile.content;
    
    // Find the thread section or create it
    const threadMarker = `#### Thread: ${threadTitle} (${message.threadId})`;
    const messageTimestamp = date.toISOString();
    
    // Convert message parts to markdown
    const messageContent = message.parts
      .map(part => {
        if (part.type === 'text') {
          return part.text;
        } else if (part.type === 'tool-call') {
          return `🔧 **Tool Call**: ${part.toolName}\n\`\`\`json\n${JSON.stringify(part.args, null, 2)}\n\`\`\``;
        } else if (part.type === 'tool-result') {
          return `📊 **Tool Result**: ${part.toolCallId}\n\`\`\`\n${typeof part.result === 'string' ? part.result : JSON.stringify(part.result, null, 2)}\n\`\`\``;
        }
        return JSON.stringify(part);
      })
      .join('\n\n');

    const messageEntry = `
##### ${message.role === 'user' ? '👤 User' : '🤖 Assistant'} (${messageTimestamp})
${messageContent}

---
`;

      // Insert message into the thread section
      if (content.includes(threadMarker)) {
        console.log('  📝 Found existing thread section, appending message...');
        // Find the thread section and append the message
        const threadSectionEnd = content.indexOf('\n#### Thread:', content.indexOf(threadMarker) + 1);
        const insertPoint = threadSectionEnd === -1 ? content.length : threadSectionEnd;
        content = content.slice(0, insertPoint) + messageEntry + content.slice(insertPoint);
      } else {
        console.log('  📝 Creating new thread section with message...');
        // Add new thread section with the message
        const newThreadSection = `${threadMarker}\n- Created: ${messageTimestamp}\n- Status: Active\n\n${messageEntry}\n`;
        content += newThreadSection;
      }

      console.log('  💾 Saving message to GitHub...');
      await this.githubClient.createOrUpdateFile(
        this.repoName,
        filePath,
        content,
        `Add message from ${message.role} in thread: ${threadTitle}`,
        existingFile?.sha
      );
      console.log('✅ DIFFDB MANAGER: Message saved successfully to GitHub');
    } catch (error) {
      console.error('❌ DIFFDB MANAGER SAVE MESSAGE ERROR:', error);
      throw error;
    }
  }

  /**
   * Load chat threads for a user
   */
  async loadThreads(limit: number = 50): Promise<ChatThread[]> {
    console.log('📚 DIFFDB MANAGER: Loading threads for user:', this.userId);
    
    try {
      const timelineFiles = await this.githubClient.listFiles(
        this.repoName, 
        `users/${this.userId}/memories/timeline`
      );
      console.log('📚 DIFFDB MANAGER: Found', timelineFiles.length, 'timeline files');

    const threads: ChatThread[] = [];
    
    // Sort files by date (newest first)
    const sortedFiles = timelineFiles
      .filter(f => f.endsWith('.md') && !f.endsWith('.gitkeep'))
      .sort((a, b) => b.localeCompare(a));

    for (const filePath of sortedFiles.slice(0, 10)) { // Limit to recent files
      const file = await this.githubClient.getFile(this.repoName, filePath);
      if (!file) continue;

      // Parse threads from the markdown content
      const content = file.content;
      const threadMatches = content.matchAll(/#### Thread: (.+?) \((.+?)\)/g);
      
      for (const match of threadMatches) {
        const title = match[1];
        const id = match[2];
        
        // Extract creation date from content
        const createdMatch = content.match(new RegExp(`${id}[\\s\\S]*?Created: ([\\d-T:.Z]+)`));
        const createdAt = createdMatch ? new Date(createdMatch[1]) : new Date();

        threads.push({
          id,
          title,
          userId: this.userId,
          createdAt,
        });

        if (threads.length >= limit) break;
      }
      
      if (threads.length >= limit) break;
    }

    console.log('✅ DIFFDB MANAGER: Loaded', threads.length, 'threads');
    return threads.slice(0, limit);
    } catch (error) {
      console.error('❌ DIFFDB MANAGER LOAD THREADS ERROR:', error);
      throw error;
    }
  }

  /**
   * Load messages for a specific thread
   */
  async loadMessages(threadId: string): Promise<ChatMessage[]> {
    console.log('💬 DIFFDB MANAGER: Loading messages for thread:', threadId);
    
    try {
      const timelineFiles = await this.githubClient.listFiles(
        this.repoName,
        `users/${this.userId}/memories/timeline`
      );
      console.log('💬 DIFFDB MANAGER: Scanning', timelineFiles.length, 'timeline files for messages');

    const messages: ChatMessage[] = [];

    for (const filePath of timelineFiles) {
      if (!filePath.endsWith('.md') || filePath.endsWith('.gitkeep')) continue;
      
      const file = await this.githubClient.getFile(this.repoName, filePath);
      if (!file) continue;

      const content = file.content;
      
      // Find the thread section
      const threadMarker = `(${threadId})`;
      if (!content.includes(threadMarker)) continue;

      // Extract messages from the thread section
      const threadStart = content.indexOf(threadMarker);
      const nextThreadStart = content.indexOf('\n#### Thread:', threadStart + 1);
      const threadContent = nextThreadStart === -1 
        ? content.slice(threadStart) 
        : content.slice(threadStart, nextThreadStart);

      // Parse messages
      const messageMatches = threadContent.matchAll(/##### (👤 User|🤖 Assistant) \(([^)]+)\)\n([\s\S]*?)(?=\n---|$)/g);
      
      for (const match of messageMatches) {
        const role = match[1].includes('User') ? 'user' : 'assistant';
        const timestamp = match[2];
        const messageContent = match[3].trim();

        // Convert markdown back to message parts
        const parts = this.parseMessageContent(messageContent);

        messages.push({
          id: nanoid(),
          threadId,
          role,
          parts,
          createdAt: new Date(timestamp),
          model: role === 'assistant' ? 'unknown' : null,
        });
      }
    }

    console.log('✅ DIFFDB MANAGER: Loaded', messages.length, 'messages for thread');
    // Sort by creation date
    return messages.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
    } catch (error) {
      console.error('❌ DIFFDB MANAGER LOAD MESSAGES ERROR:', error);
      throw error;
    }
  }

  /**
   * Parse markdown message content back to message parts
   */
  private parseMessageContent(content: string): any[] {
    // Simple parsing - can be enhanced
    if (content.includes('🔧 **Tool Call**:')) {
      // Tool call message
      const toolMatch = content.match(/🔧 \*\*Tool Call\*\*: (.+?)\n```json\n([\s\S]*?)\n```/);
      if (toolMatch) {
        return [{
          type: 'tool-call',
          toolCallId: nanoid(),
          toolName: toolMatch[1],
          args: JSON.parse(toolMatch[2]),
        }];
      }
    } else if (content.includes('📊 **Tool Result**:')) {
      // Tool result message
      const resultMatch = content.match(/📊 \*\*Tool Result\*\*: (.+?)\n```\n([\s\S]*?)\n```/);
      if (resultMatch) {
        return [{
          type: 'tool-result',
          toolCallId: resultMatch[1],
          result: resultMatch[2],
        }];
      }
    } else {
      // Regular text message
      return [{
        type: 'text',
        text: content,
      }];
    }

    return [{
      type: 'text',
      text: content,
    }];
  }

  /**
   * Delete a thread and its messages
   */
  async deleteThread(threadId: string): Promise<void> {
    // For now, we'll mark as deleted rather than actually deleting
    // This preserves the Git history
    const timelineFiles = await this.githubClient.listFiles(
      this.repoName,
      `users/${this.userId}/memories/timeline`
    );

    for (const filePath of timelineFiles) {
      if (!filePath.endsWith('.md')) continue;
      
      const file = await this.githubClient.getFile(this.repoName, filePath);
      if (!file || !file.content.includes(`(${threadId})`)) continue;

      // Mark thread as deleted
      const updatedContent = file.content.replace(
        new RegExp(`(#### Thread: .+ \\(${threadId}\\)[\\s\\S]*?)- Status: Active`, 'g'),
        '$1- Status: Deleted'
      );

      await this.githubClient.createOrUpdateFile(
        this.repoName,
        filePath,
        updatedContent,
        `Delete thread: ${threadId}`,
        file.sha
      );
    }
  }
}
